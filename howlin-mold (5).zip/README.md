# Howlin Mold - Vault of Echoes

A mystical multi-deck ritual vinyl platform built with Next.js 14, featuring dynamic color themes, WebGL visuals, and an immersive "SigilMesh x Vault of Echoes" aesthetic.

## Features

- 🎨 Dynamic session-based color themes
- 🔮 Custom sigil navigation with glass morphism effects
- 🌌 WebGL visual effects with Three.js
- 🎵 Multi-deck DJ interface
- 🛡️ Role-based authentication system
- 📱 Fully responsive design
- ⚡ Built with Next.js 14 App Router

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
\`\`\`bash
git clone <your-repo-url>
cd howlin-mold
\`\`\`

2. Install dependencies:
\`\`\`bash
npm install
\`\`\`

3. Run the development server:
\`\`\`bash
npm run dev
\`\`\`

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

### Demo Credentials

- **Admin**: admin@howlinmold.com / admin123
- **User**: user@howlinmold.com / user123

## Project Structure

\`\`\`
howlin-mold/
├── app/                    # Next.js 14 App Router
├── components/             # React components
│   ├── providers/         # Context providers
│   ├── sigils/           # Custom sigil components
│   └── ui/               # UI components
├── lib/                   # Utilities and contexts
└── public/               # Static assets
\`\`\`

## Tech Stack

- **Framework**: Next.js 14 with App Router
- **Styling**: Tailwind CSS with custom design system
- **3D Graphics**: Three.js with React Three Fiber
- **Animation**: Framer Motion
- **Typography**: Space Grotesk, Orbitron, EB Garamond
- **Icons**: Custom SVG sigils + Lucide React

## Color System

The application features a dynamic color system that generates unique themes for each session:

- **Primary**: Brass Gold variations
- **Secondary**: Charred Amethyst tones  
- **Accent**: Pale Cyan highlights
- **Background**: Vantablack to Amethyst gradient

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

### Environment Variables

No environment variables required for basic functionality. All features work with mock data.

## License

Private project - All rights reserved.
